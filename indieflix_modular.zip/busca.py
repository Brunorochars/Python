def buscar_filme(filmes: list):
    print("\n=====| Buscar Filmes |=====")
    titulo = input("Título (ou parte): ").lower().strip()
    diretor = input("Diretor (ou parte): ").lower().strip()
    genero = input("Gênero: ").lower().strip()
    ano_min = input("Ano mínimo: ").strip()
    ano_max = input("Ano máximo: ").strip()
    ordenar = input("Ordenar por ano? (s/n): ").lower().strip() == "s"
    resultados = []
    for f in filmes:
        if titulo and titulo not in f["titulo"].lower():
            continue
        if diretor and diretor not in f["diretor"].lower():
            continue
        if genero and genero not in f["genero"].lower():
            continue
        if ano_min and f["ano_lancamento"] < int(ano_min):
            continue
        if ano_max and f["ano_lancamento"] > int(ano_max):
            continue
        resultados.append(f)
    if ordenar:
        resultados.sort(key=lambda x: x["ano_lancamento"])
    print("\n=====| Resultados |=====")
    if not resultados:
        print("Nenhum filme encontrado.")
    else:
        for f in resultados:
            print(f"[{f['id']}] {f['titulo']} | {f['diretor']} | {f['ano_lancamento']} | {f['genero']} | {f['duracao']} min | Nota: {f['nota_pessoal']}")